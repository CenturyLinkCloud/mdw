/*
 * Copyright (c) 2011 Qwest, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Qwest, Inc. ("Confidential Information").  You shall not disclose
 * such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Qwest.
 *
 * QWEST MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. QWEST SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 */

package com.centurylink.swt.widgets;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class Tester
{
  public static void main(String[] args)
  {
    Display display = new Display();
    Shell shell = new Shell(display);
    
    Label label = new Label(shell, SWT.NONE);
    label.setText("Custom: ");
    
    final CTreeCombo treeCombo = new CTreeCombo(shell, SWT.BORDER | SWT.FULL_SELECTION);
    GridData gd = new GridData(GridData.BEGINNING);
    gd.heightHint = 17;
    treeCombo.setLayoutData(gd);

    CTreeComboItem item = new CTreeComboItem(treeCombo, SWT.NONE);
    item.setText("Parent 1");

    CTreeComboItem childItem = new CTreeComboItem(item, SWT.NONE);
    childItem.setText("Child 1.1");

    childItem = new CTreeComboItem(item, SWT.NONE);
    childItem.setText("Child 1.2");

    item = new CTreeComboItem(treeCombo, SWT.NONE);
    item.setText("Parent 2");

    childItem = new CTreeComboItem(item, SWT.NONE);
    childItem.setText("Child 2.1");

    childItem = new CTreeComboItem(item, SWT.NONE);
    childItem.setText("Child 2.2");
    
    treeCombo.addListener(SWT.Selection, new Listener()
    {
      public void handleEvent(Event event)
      {
        if (treeCombo.getText().startsWith("Parent"))
        {
          treeCombo.setSelection(new CTreeComboItem[0]);
        }
        else
        {
          try
          {
            Thread.sleep(200);
          }
          catch (InterruptedException ex)
          {
          }
          treeCombo.dropDown(false);
        }
      }
    });
    

    treeCombo.setText("Child 1.2");
    
    
    
    Combo combo = new Combo(shell, SWT.DROP_DOWN | SWT.BORDER);
    combo.add("Item 1");
    combo.add("Item 2");
    
    CCombo ccombo = new CCombo(shell, SWT.DROP_DOWN | SWT.BORDER);
    ccombo.add("Item 1");
    ccombo.add("Item 2");
    ccombo.setText("Item 2");

    GridLayout gl = new GridLayout();
    gl.numColumns = 4;
    shell.setLayout(gl);
    shell.pack();
    shell.open();
    while (!shell.isDisposed())
    {
      if (!display.readAndDispatch())
        display.sleep ();
    }
    display.dispose ();
  }

}
