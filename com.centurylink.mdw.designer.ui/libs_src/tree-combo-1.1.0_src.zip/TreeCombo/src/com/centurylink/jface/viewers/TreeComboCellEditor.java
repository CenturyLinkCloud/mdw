package com.centurylink.jface.viewers;

import java.text.MessageFormat;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

import com.centurylink.swt.widgets.CTreeCombo;
import com.centurylink.swt.widgets.CTreeComboItem;

/**
 * Only supports a single selection.
 */
public class TreeComboCellEditor extends CellEditor
{
  private CTreeCombo treeCombo;
  public CTreeCombo getTreeCombo() { return treeCombo; }

  private SelectionModifier selectionModifier;
  public SelectionModifier getSelectionModifier() { return selectionModifier; }
  public void setSelectionModifier(SelectionModifier modifier) { this.selectionModifier = modifier; }
  
  public TreeComboCellEditor(Composite parent)
  {
    this(parent, SWT.BORDER | SWT.FULL_SELECTION);
  }

  public TreeComboCellEditor(Composite parent, int style)
  {
    super(parent, style);
  }
  
  /**
   * Adds a top-level item.
   */
  public CTreeComboItem addItem(String label)
  {
    CTreeComboItem item = new CTreeComboItem(treeCombo, SWT.None);
    item.setText(label);
    return item;
  }

  protected Control createControl(Composite parent)
  {
    treeCombo = new CTreeCombo(parent, getStyle());

    treeCombo.addKeyListener(new KeyAdapter()
    {
      public void keyPressed(KeyEvent e)
      {
        keyReleaseOccured(e);
      }
    });
    
    treeCombo.addListener(SWT.Selection, new Listener()
    {
      public void handleEvent(Event event)
      {
        CTreeComboItem[] selItems = treeCombo.getSelection();
        if (selItems.length == 1)
        {
          CTreeComboItem selItem = selItems[0];
          if (selItem.getItemCount() != 0)
          {
            // ignore non-node selection
            treeCombo.setSelection(new CTreeComboItem[0]);
          }
          else
          {
            try
            {
              Thread.sleep(100);
            }
            catch (InterruptedException ex)
            {
            }
            String selText = selItem.getText();
            if (selectionModifier != null)
              selText = selectionModifier.modify(selItem);
            
            treeCombo.setText(selText);
            applyEditorValueAndDeactivate();
          }
        }
      }
    });    

    treeCombo.addTraverseListener(new TraverseListener()
    {
      public void keyTraversed(TraverseEvent e)
      {
        if (e.detail == SWT.TRAVERSE_ESCAPE || e.detail == SWT.TRAVERSE_RETURN)
        {
          e.doit = false;
        }
      }
    });

    treeCombo.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent e)
      {
        TreeComboCellEditor.this.focusLost();
      }

      @Override
      public void focusGained(FocusEvent e)
      {
        TreeComboCellEditor.this.focusGained();
      }
      
    });
    
    return treeCombo;
  }

  protected Object doGetValue()
  {
    CTreeComboItem[] items = treeCombo.getSelection();
    if (items.length == 0)
      return treeCombo.getText();
    else
      return items[0];
  }
  
  protected void doSetValue(Object value)
  {
    if (value instanceof String)
      treeCombo.setText((String)value);
    else
      treeCombo.setSelection(new CTreeComboItem[] {(CTreeComboItem)value});
  }

  protected void doSetFocus()
  {
    treeCombo.setVisible(true);
    treeCombo.setFocus();
  }

  public LayoutData getLayoutData()
  {
    LayoutData layoutData = super.getLayoutData();
    if ((treeCombo == null) || treeCombo.isDisposed())
    {
      layoutData.minimumWidth = 60;
    }
    else
    {
      // make the treeCombo 10 characters wide
      GC gc = new GC(treeCombo);
      layoutData.minimumWidth = (gc.getFontMetrics().getAverageCharWidth() * 10) + 10;
      gc.dispose();
    }
    return layoutData;
  }


  void applyEditorValueAndDeactivate()
  {
    Object newValue = doGetValue();
    markDirty();
    boolean isValid = isCorrect(newValue);
    setValueValid(isValid);

    if (!isValid)
    {
      setErrorMessage(MessageFormat.format(getErrorMessage(), new Object[] {treeCombo.getText()}));
    }

    fireApplyEditorValue();
    deactivate();
  }

  protected void focusGained()
  {
    treeCombo.setVisible(true);    
    if (!isActivated())
      activate();
  }
  
  protected void focusLost()
  {
    if (isActivated())
      applyEditorValueAndDeactivate();
  }
  
  
  public void deactivate()
  {
    if (!treeCombo.isDisposed())
    {
      treeCombo.setVisible(true);
      treeCombo.dropDown(false);
    }
    super.deactivate();
  }

  protected void keyReleaseOccured(KeyEvent keyEvent)
  {
    if (keyEvent.character == '\u001b')
    { // escape character
      fireCancelEditor();
      treeCombo.dropDown(false);
    }
    else if (keyEvent.character == '\t')
    { // tab key
      applyEditorValueAndDeactivate();
    }
  }
  
  public interface SelectionModifier
  {
    public String modify(CTreeComboItem selection);
  }
}
